 <script language="JavaScript" type="text/JavaScript">
            function check_upload(prm_this)
            {
                window.opener.document.acForm.upload_facility.value=prm_this;
                window.close();
            }
        </script>
